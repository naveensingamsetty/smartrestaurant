package com.example.naveens.smrtaccordion;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseExpandableListAdapter;
import android.widget.TextView;

import java.util.List;
import java.util.Map;

/**
 * Created by naveen.s on 3/6/2017.
 */

public class MyExListAdapter extends BaseExpandableListAdapter {

    Context context;
    List<String> Course;
    Map<String,List<String>> items;

    public MyExListAdapter(Context context, List<String> course, Map<String, List<String>> items) {
        this.context = context;
        Course = course;
        this.items = items;
    }

    @Override
    public int getGroupCount() {
        return Course.size();
    }

    @Override
    public int getChildrenCount(int groupPosition) {
        return items.get(Course.get(groupPosition)).size() ;
    }

    @Override
    public Object getGroup(int groupPosition) {
        return Course.get(groupPosition);
    }

    @Override
    public Object getChild(int groupPosition, int childPosition) {
        return items.get(Course.get(groupPosition)).get(childPosition);
    }

    @Override
    public long getGroupId(int groupPosition) {
        return groupPosition;
    }

    @Override
    public long getChildId(int groupPosition, int childPosition) {
        return childPosition;
    }

    @Override
    public boolean hasStableIds() {
        return false;
    }

    @Override
    public View getGroupView(int groupPosition, boolean isExpanded, View convertView, ViewGroup parent) {

        String Course = (String) getGroup(groupPosition);

        if (convertView == null)
        {
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(context.LAYOUT_INFLATER_SERVICE);
            convertView = inflater.inflate(R.layout.list_parent,null);
        }

        TextView txtParent = (TextView) convertView.findViewById(R.id.txtParent);
        txtParent.setText(Course);


        return convertView;
    }

    @Override
    public View getChildView(int groupPosition, int childPosition, boolean isLastChild, View convertView, ViewGroup parent) {

        String items = (String) getChild(groupPosition,childPosition);

        if (convertView == null)
        {
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(context.LAYOUT_INFLATER_SERVICE);
            convertView = inflater.inflate(R.layout.list_child,null);
        }
        TextView txtchild = (TextView) convertView.findViewById(R.id.txtchild);
        txtchild.setText(items);
        return convertView;
    }

    @Override
    public boolean isChildSelectable(int groupPosition, int childPosition) {
        return true;
    }
}
