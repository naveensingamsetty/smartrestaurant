package com.example.naveens.smrtaccordion;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ExpandableListAdapter;
import android.widget.ExpandableListView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MainActivity extends AppCompatActivity {

    ExpandableListView expandableListView;

    List<String> course;
    Map<String,List<String>> items;
    ExpandableListAdapter listAdapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        expandableListView = (ExpandableListView) findViewById(R.id.expandablelistview);
        filldata();


        listAdapter = new MyExListAdapter(this,course,items);
        expandableListView.setAdapter(listAdapter);
        expandableListView.setOnChildClickListener(new ExpandableListView.OnChildClickListener() {
            @Override
            public boolean onChildClick(ExpandableListView parent, View v, int groupPosition, int childPosition, long id) {

                Toast.makeText(MainActivity.this,course.get(groupPosition) + ":" + items.get(course.get(childPosition)).get(childPosition),Toast.LENGTH_LONG).show();


                return false;
            }

        });



    }

    public void filldata()
    {

        course = new ArrayList<>();
        items = new HashMap<>();

        course.add("Starters");
        course.add("Main Course");
        course.add("Deserts");

        List<String> Starters = new ArrayList<>();
        List<String> Main_Course = new ArrayList<>();
        List<String> Deserts = new ArrayList<>();

        Starters.add("Loaded Fries");
        Starters.add("Chicken Wings");
        Starters.add("Nachos");

        Main_Course.add("Pasta");
        Main_Course.add("Biriyani");
        Main_Course.add("Noodles");

        Deserts.add("Ice Cream");
        Deserts.add("Caramel Cracker");

        items.put(course.get(0),Starters);
        items.put(course.get(1),Main_Course);
        items.put(course.get(2),Deserts);



    }
}
